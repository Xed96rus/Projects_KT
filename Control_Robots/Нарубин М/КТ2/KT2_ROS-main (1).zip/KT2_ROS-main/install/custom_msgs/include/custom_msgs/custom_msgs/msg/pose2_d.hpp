// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_MSGS__MSG__POSE2_D_HPP_
#define CUSTOM_MSGS__MSG__POSE2_D_HPP_

#include "custom_msgs/msg/detail/pose2_d__struct.hpp"
#include "custom_msgs/msg/detail/pose2_d__builder.hpp"
#include "custom_msgs/msg/detail/pose2_d__traits.hpp"
#include "custom_msgs/msg/detail/pose2_d__type_support.hpp"

#endif  // CUSTOM_MSGS__MSG__POSE2_D_HPP_
