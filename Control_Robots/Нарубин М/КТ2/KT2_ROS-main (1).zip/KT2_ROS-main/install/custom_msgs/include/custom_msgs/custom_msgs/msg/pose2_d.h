// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_msgs:msg/Pose2D.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_MSGS__MSG__POSE2_D_H_
#define CUSTOM_MSGS__MSG__POSE2_D_H_

#include "custom_msgs/msg/detail/pose2_d__struct.h"
#include "custom_msgs/msg/detail/pose2_d__functions.h"
#include "custom_msgs/msg/detail/pose2_d__type_support.h"

#endif  // CUSTOM_MSGS__MSG__POSE2_D_H_
