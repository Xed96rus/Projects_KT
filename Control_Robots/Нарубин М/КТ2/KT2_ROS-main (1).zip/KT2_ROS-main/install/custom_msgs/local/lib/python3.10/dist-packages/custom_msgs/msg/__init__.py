from custom_msgs.msg._pose2_d import Pose2D  # noqa: F401
